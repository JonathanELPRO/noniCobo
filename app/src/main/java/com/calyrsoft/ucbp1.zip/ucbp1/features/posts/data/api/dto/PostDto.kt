package com.calyrsoft.ucbp1.features.posts.data.api.dto

data class PostDto(val userId: String,
                   val id: String,
                   val title: String,
                   val body: String)

