package com.calyrsoft.ucbp1.features.posts.domain.model

data class PostModel(
    val userId: String,
    val id: String,
    val title: String,
    val body: String
)