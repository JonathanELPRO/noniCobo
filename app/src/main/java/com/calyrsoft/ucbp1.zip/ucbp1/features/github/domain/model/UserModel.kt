package com.calyrsoft.ucbp1.features.github.domain.model

data class UserModel(val nickname: Nickname, val pathUrl: UrlPath)