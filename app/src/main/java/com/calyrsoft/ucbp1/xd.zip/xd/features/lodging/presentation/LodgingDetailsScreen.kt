package com.calyrsoft.ucbp1.features.lodging.presentation

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LodgingDetailsScreen(
    id: Long,
    vm: LodgingDetailsViewModel = viewModel(),
    onBack: () -> Unit = {}
) {
    val lodging by vm.lodging.collectAsState()
    val scope = rememberCoroutineScope()

    LaunchedEffect(id) {
        scope.launch { vm.load(id) }
    }

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = { Text(lodging?.name ?: "Detalles del alojamiento") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Volver")
                    }
                }
            )
        }
    ) { padding ->
        lodging?.let { l ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text("Tipo: ${l.type}")
                Text("Dirección: ${l.address ?: "No registrada"}")
                Text("Zona: ${l.district ?: "-"}")
                Text("Teléfono: ${l.contactPhone ?: "No disponible"}")
                Text("Atiende 24h: ${if (l.open24h) "Sí" else "No"}")
                Text("Baño privado: ${if (l.hasPrivateBathroom) "Sí" else "No"}")
                Text("Smart TV: ${if (l.hasSmartTV) "Sí" else "No"}")

                Divider(thickness = 1.dp, modifier = Modifier.padding(vertical = 8.dp))

                Text("Tipos de habitación:", style = MaterialTheme.typography.titleMedium)
                if (l.roomTypes.isEmpty()) {
                    Text("No hay habitaciones registradas.")
                } else {
                    l.roomTypes.forEach { room ->
                        Text("• ${room.name} (Bs. ${room.pricePerNight ?: room.pricePerHour ?: room.pricePerDay})")
                    }
                }
            }
        } ?: Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentAlignment = Alignment.Center
        ) {
            CircularProgressIndicator()
        }
    }
}
