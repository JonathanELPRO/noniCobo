package com.calyrsoft.ucbp1.features.reviews.domain.usecase

class GetReviewsForLodgingUseCase {
}