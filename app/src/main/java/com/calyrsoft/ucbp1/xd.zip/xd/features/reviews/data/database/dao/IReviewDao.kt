package com.calyrsoft.ucbp1.features.reviews.data.database.dao

interface IReviewDao {
}