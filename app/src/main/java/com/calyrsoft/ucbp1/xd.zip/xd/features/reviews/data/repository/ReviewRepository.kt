package com.calyrsoft.ucbp1.features.reviews.data.repository

class ReviewRepository {
}