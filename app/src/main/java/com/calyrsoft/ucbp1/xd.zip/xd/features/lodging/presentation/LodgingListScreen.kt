package com.calyrsoft.ucbp1.features.lodging.presentation

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.calyrsoft.ucbp1.features.auth.presentation.AuthViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LodgingListScreen(
    vm: LodgingListViewModel = viewModel(),
    onDetails: (Long) -> Unit
) {
    val lodgings by vm.lodgings.collectAsState()

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(title = { Text("Alojamientos disponibles") })
        }
    ) { innerPadding ->
        if (lodgings.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding),
                contentAlignment = Alignment.Center
            ) {
                Text("No hay alojamientos registrados.")
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                items(lodgings) { lodging ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 8.dp)
                            .clickable { lodging.id?.let(onDetails) },
                        elevation = CardDefaults.cardElevation(4.dp)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(
                                text = lodging.name,
                                style = MaterialTheme.typography.titleMedium
                            )
                            Text(
                                text = lodging.type.name,
                                style = MaterialTheme.typography.labelLarge
                            )
                            lodging.district?.let {
                                Text(text = "Zona: $it", style = MaterialTheme.typography.bodyMedium)
                            }
                            val price = lodging.pricePerHour ?: lodging.pricePerNight ?: lodging.pricePerDay
                            if (price != null) {
                                Text(
                                    text = "Desde Bs. ${"%.2f".format(price)}",
                                    style = MaterialTheme.typography.bodyMedium
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
