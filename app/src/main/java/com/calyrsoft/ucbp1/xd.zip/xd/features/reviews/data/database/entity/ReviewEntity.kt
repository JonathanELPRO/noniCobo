package com.calyrsoft.ucbp1.features.reviews.data.database.entity

class ReviewEntity {
}