package com.calyrsoft.ucbp1.features.reviews.domain.model

class Review {
}