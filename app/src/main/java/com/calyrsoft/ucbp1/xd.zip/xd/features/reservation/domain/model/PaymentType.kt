package com.calyrsoft.ucbp1.features.reservation.domain.model
enum class PaymentType { ADVANCE, REMAINING }