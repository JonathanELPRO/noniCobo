package com.calyrsoft.ucbp1.features.auth.domain.model
enum class Role { CLIENT, ADMIN }