package com.calyrsoft.ucbp1.features.reviews.presentation

class ReviewsViewModel {
}