package com.calyrsoft.ucbp1.features.reviews.domain.repository

interface IReviewRepository {
}