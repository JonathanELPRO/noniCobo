package com.calyrsoft.ucbp1.features.posts.data.api.dto

data class PostsPageDto(
    val posts: List<PostDto>,
)
