package com.calyrsoft.ucbp1.features.lodging.domain.model

enum class LodgingType { MOTEL, RESIDENCIAL }