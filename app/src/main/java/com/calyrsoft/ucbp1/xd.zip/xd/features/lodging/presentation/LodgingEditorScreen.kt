package com.calyrsoft.ucbp1.features.lodging.presentation

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.calyrsoft.ucbp1.features.auth.domain.model.Role
import com.calyrsoft.ucbp1.features.lodging.domain.model.Lodging
import com.calyrsoft.ucbp1.features.lodging.domain.model.LodgingType
import com.calyrsoft.ucbp1.features.lodging.domain.usecase.UpsertLodgingUseCase
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LodgingEditorScreen(
    currentRole: Role,
    useCase: UpsertLodgingUseCase,
    onSaved: () -> Unit = {}
) {
    var name by remember { mutableStateOf("") }
    var type by remember { mutableStateOf(LodgingType.MOTEL) }
    var address by remember { mutableStateOf("") }
    var district by remember { mutableStateOf("") }
    var contact by remember { mutableStateOf("") }
    var price by remember { mutableStateOf("") }

    val scope = rememberCoroutineScope()
    var isLoading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    Scaffold(
        topBar = { CenterAlignedTopAppBar(title = { Text("Nuevo alojamiento") }) }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Nombre") })
            OutlinedTextField(value = address, onValueChange = { address = it }, label = { Text("Dirección") })
            OutlinedTextField(value = district, onValueChange = { district = it }, label = { Text("Zona/Barrio") })
            OutlinedTextField(value = contact, onValueChange = { contact = it }, label = { Text("Teléfono") })
            OutlinedTextField(value = price, onValueChange = { price = it }, label = { Text("Precio base (Bs)") })

            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Tipo:")
                Spacer(Modifier.width(8.dp))
                DropdownMenuDemo(type) { type = it }
            }

            Button(
                onClick = {
                    scope.launch {
                        try {
                            isLoading = true
                            val lodging = Lodging(
                                name = name,
                                type = type,
                                district = district,
                                address = address,
                                contactPhone = contact,
                                open24h = false,
                                ownerAdminId = 1L,
                                pricePerHour = price.toDoubleOrNull(),
                                pricePerNight = null,
                                pricePerDay = null,
                                hasPrivateBathroom = false,
                                hasSmartTV = false,
                                latitude = null,
                                longitude = null
                            )
                            useCase(currentRole, lodging)
                            onSaved()
                        } catch (e: Exception) {
                            error = e.message
                        } finally {
                            isLoading = false
                        }
                    }
                },
                enabled = !isLoading
            ) {
                Text(if (isLoading) "Guardando..." else "Guardar")
            }

            error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        }
    }
}

@Composable
private fun DropdownMenuDemo(
    currentType: LodgingType,
    onSelect: (LodgingType) -> Unit
) {
    var expanded by remember { mutableStateOf(false) }
    Box {
        Button(onClick = { expanded = true }) {
            Text(currentType.name)
        }
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            LodgingType.values().forEach { t ->
                DropdownMenuItem(
                    text = { Text(t.name) },
                    onClick = {
                        onSelect(t)
                        expanded = false
                    }
                )
            }
        }
    }
}
