package com.calyrsoft.ucbp1.features.reservation.domain.model
enum class StayType { HOUR, NIGHT, DAY }